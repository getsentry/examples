# Sentry PHP CodeIgniter Example

You must set your DSN in [index.php](https://github.com/getsentry/examples/blob/master/php/codeigniter/index.php).
